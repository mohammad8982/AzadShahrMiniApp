# Azad Shahr — Animal Quest

نسخه ۱ رابط Mini App + پنل مدیریت آزمایشی.

## اجرای سریع
فقط `index.html` را روی GitHub Pages قرار بده. نسخه فعلی بدون Backend هم برای تست رابط و مکانیک‌های اولیه کار می‌کند و داده‌ها را در LocalStorage نگه می‌دارد.

پنل آزمایشی:
`/admin.html`

## معماری نسخه تولیدی
- Frontend: GitHub Pages
- Backend: FastAPI
- Database: PostgreSQL
- Cache/Rate limit: Redis
- Telegram: WebApp initData verification
- Admin: اتصال به API امن

## نکته مهم
برای نسخه واقعی، موجودی، انرژی، خرید، Referral و پاداش نباید فقط در JavaScript یا LocalStorage باشند. این نسخه عمداً لایه Frontend را آماده می‌کند و `backend/main.py` قرارداد API تولیدی را مشخص می‌کند.
