"""
Backend blueprint for the production version.
GitHub Pages cannot run this server; deploy it separately (Render/Railway/VPS).
This file intentionally contains the API contract and safe server-side validation skeleton.
"""
import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Animal Quest API", version="1.0.0")

class CollectRequest(BaseModel):
    user_id: int
    client_nonce: str = Field(min_length=8, max_length=128)

@app.get("/health")
def health():
    return {"ok": True, "service": "animal-quest-api"}

@app.post("/v1/game/collect")
def collect(req: CollectRequest):
    # Production implementation:
    # 1) verify Telegram WebApp initData on the server
    # 2) load user from DB inside a transaction
    # 3) calculate reward from server-side animal/upgrade state
    # 4) validate energy and cooldown
    # 5) atomically update balance + transaction ledger
    # 6) return authoritative state
    raise HTTPException(501, "Connect this endpoint to the production database before launch.")
