(() => {
  "use strict";
  const KEY="azadshahr_animal_quest_v1";
  const base={
    coins:1250, energy:100, maxEnergy:100, level:1, xp:0,
    featured:"fox", owned:["fox"], upgrades:{fox:1},
    missions:{collect:0,upgrade:0,invite:0}, claimed:{},
    username:"بازیکن"
  };
  const animals=[
    {id:"fox",name:"روباه طلایی",icon:"🦊",income:12,cost:0,desc:"حیوان آغازین و سریع"},
    {id:"panda",name:"پاندای آرام",icon:"🐼",income:32,cost:2500,desc:"درآمد پایدار"},
    {id:"tiger",name:"ببر سلطنتی",icon:"🐯",income:80,cost:10000,desc:"درآمد ویژه"}
  ];
  const missions=[
    {id:"collect",title:"۱۰ بار جمع‌آوری",icon:"⚡",target:10,reward:500},
    {id:"upgrade",title:"یک ارتقا انجام بده",icon:"⬆️",target:1,reward:800},
    {id:"invite",title:"یک دوست دعوت کن",icon:"👥",target:1,reward:1000}
  ];
  const state=load();
  const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
  function load(){try{return {...base,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch{return {...base}}}
  function save(){localStorage.setItem(KEY,JSON.stringify(state))}
  function fmt(n){return Number(n||0).toLocaleString("fa-IR")}
  function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");clearTimeout(window.__t);window.__t=setTimeout(()=>e.classList.remove("show"),1800)}
  function animal(id){return animals.find(a=>a.id===id)||animals[0]}
  function level(){state.level=1+Math.floor(state.xp/2500)}
  function render(){
    level();
    $("#coins").textContent=fmt(state.coins); $("#energy").textContent=fmt(state.energy); $("#maxEnergy").textContent=fmt(state.maxEnergy);
    $("#level").textContent=fmt(state.level); $("#welcome").textContent=state.username==="بازیکن"?"آماده‌ای؟":`سلام ${state.username}`;
    const a=animal(state.featured), up=state.upgrades[a.id]||1, income=a.income*up;
    $("#heroAvatar").textContent=a.icon; $("#collectAmount").textContent="+"+fmt(income);
    $("#featuredAnimal").innerHTML=`<div class="animal-icon">${a.icon}</div><div class="animal-info"><b>${a.name} • سطح ${up}</b><small>${a.desc} · هر جمع‌آوری</small></div><div class="animal-income">+${fmt(income)}</div>`;
    const done=Object.keys(state.claimed).filter(k=>state.claimed[k]).length;
    $("#dailyDone").textContent=done; $("#dailyPct").textContent=Math.round(done/5*100)+"%"; $("#dailyBar").style.width=Math.min(100,done/5*100)+"%";
    renderAnimals(); renderMissions(); renderShop(); renderLeaderboard(); save();
  }
  function renderAnimals(){
    $("#animalsList").innerHTML=animals.map(a=>{
      const owned=state.owned.includes(a.id), up=state.upgrades[a.id]||1;
      return `<div class="list-card"><div class="list-icon">${a.icon}</div><div class="list-main"><b>${a.name} ${owned?`· سطح ${up}`:""}</b><small>${a.desc} · درآمد ${fmt(a.income*up)}</small></div>${owned?`<button class="list-action ${state.featured===a.id?"gold":""}" data-animal="${a.id}">${state.featured===a.id?"فعال":"انتخاب"}</button>`:`<button class="list-action ${state.coins>=a.cost?"gold":""}" data-buy="${a.id}">${fmt(a.cost)} 🪙</button>`}</div>`
    }).join("");
  }
  function renderMissions(){
    $("#missionsList").innerHTML=missions.map(m=>{
      const p=Math.min(state.missions[m.id]||0,m.target), claimed=!!state.claimed[m.id];
      return `<div class="list-card"><div class="list-icon">${m.icon}</div><div class="list-main"><b>${m.title}</b><small>${p}/${m.target} · پاداش ${fmt(m.reward)} سکه</small></div>${claimed?`<button class="list-action">دریافت شد</button>`:p>=m.target?`<button class="list-action gold" data-claim="${m.id}">دریافت</button>`:`<button class="list-action">${p}/${m.target}</button>`}</div>`
    }).join("");
  }
  function renderShop(){
    const a=animal(state.featured), up=state.upgrades[a.id]||1, cost=Math.round(300*Math.pow(1.8,up-1));
    $("#shopList").innerHTML=`<div class="list-card"><div class="list-icon">⬆️</div><div class="list-main"><b>ارتقای ${a.name}</b><small>درآمد فعلی ${fmt(a.income*up)} → ${fmt(a.income*(up+1))}</small></div><button class="list-action ${state.coins>=cost?"gold":""}" data-upgrade="${a.id}">${fmt(cost)} 🪙</button></div>
    <div class="list-card"><div class="list-icon">⚡</div><div class="list-main"><b>افزایش ظرفیت انرژی</b><small>ظرفیت فعلی ${state.maxEnergy}</small></div><button class="list-action ${state.coins>=1500?"gold":""}" id="energyUp">1,500 🪙</button></div>`;
  }
  function renderLeaderboard(){
    const names=["ShadowFox","GoldenPanda","Arman","Nima","Player"];
    $("#leaderboardList").innerHTML=names.map((n,i)=>`<div class="list-card"><div class="list-icon">${["🥇","🥈","🥉","🏅","⭐"][i]}</div><div class="list-main"><b>${n}</b><small>سطح ${12-i} · امتیاز ${fmt(98500-i*12400)}</small></div></div>`).join("");
  }
  function go(page){
    $$(".page").forEach(x=>x.classList.toggle("active",x.id==="page-"+page));
    $$(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
    window.scrollTo({top:0,behavior:"smooth"});
  }
  document.addEventListener("click",e=>{
    const p=e.target.closest("[data-page]"); if(p) return go(p.dataset.page);
    const a=e.target.closest("[data-animal]"); if(a){state.featured=a.dataset.animal;toast("حیوان فعال شد");render();return}
    const buy=e.target.closest("[data-buy]"); if(buy){const a=animal(buy.dataset.buy);if(state.coins<a.cost)return toast("سکه کافی نیست");state.coins-=a.cost;state.owned.push(a.id);state.upgrades[a.id]=1;state.featured=a.id;toast("حیوان جدید به مجموعه اضافه شد");render();return}
    const up=e.target.closest("[data-upgrade]"); if(up){const id=up.dataset.upgrade,lv=state.upgrades[id]||1,cost=Math.round(300*Math.pow(1.8,lv-1));if(state.coins<cost)return toast("سکه کافی نیست");state.coins-=cost;state.upgrades[id]=lv+1;state.xp+=250;state.missions.upgrade=Math.min(1,(state.missions.upgrade||0)+1);toast("ارتقا با موفقیت انجام شد");render();return}
    const cl=e.target.closest("[data-claim]"); if(cl){const m=missions.find(x=>x.id===cl.dataset.claim);if((state.missions[m.id]||0)<m.target)return;state.coins+=m.reward;state.claimed[m.id]=true;state.xp+=300;toast("پاداش دریافت شد 🎁");render();return}
    if(e.target.id==="collectBtn"){const a=animal(state.featured),income=a.income*(state.upgrades[a.id]||1);if(state.energy<5)return toast("انرژی کافی نیست");state.energy-=5;state.coins+=income;state.xp+=10;state.missions.collect=Math.min(10,(state.missions.collect||0)+1);toast(`+${fmt(income)} سکه دریافت کردی`);render()}
    if(e.target.id==="energyUp"){if(state.coins<1500)return toast("سکه کافی نیست");state.coins-=1500;state.maxEnergy+=25;state.energy=state.maxEnergy;toast("ظرفیت انرژی افزایش یافت");render()}
    if(e.target.id==="copyRef"){const link="https://t.me/YourBot?start=ref_"+(window.Telegram?.WebApp?.initDataUnsafe?.user?.id||"demo");navigator.clipboard?.writeText(link).then(()=>toast("لینک دعوت کپی شد")).catch(()=>toast(link))}
    if(e.target.id==="profileBtn"){toast("پروفایل در نسخه بعدی با Telegram User وصل می‌شود")}
  });
  // Telegram Mini App safe initialization
  try{
    if(window.Telegram?.WebApp){Telegram.WebApp.ready();Telegram.WebApp.expand();Telegram.WebApp.setHeaderColor("#07090d");Telegram.WebApp.setBackgroundColor("#07090d");
      const u=Telegram.WebApp.initDataUnsafe?.user;if(u){state.username=u.first_name||u.username||"بازیکن"}}
  }catch(_){}
  setInterval(()=>{if(state.energy<state.maxEnergy){state.energy=Math.min(state.maxEnergy,state.energy+1);render()}},30000);
  render();
})();